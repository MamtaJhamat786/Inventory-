package com.company;

public class Vender {
  private String nameOfCompany;
  private String address;
  private String representativeName;
  private String phoneNumber;

  public Vender(String nameOfCompany, String address, String representativeName, String phoneNumber) {
    this.nameOfCompany = nameOfCompany;
    this.address = address;
    this.representativeName = representativeName;
    this.phoneNumber = phoneNumber;
  }

  public Vender(){

  }

  public String getNameOfCompany() {
    return nameOfCompany;
  }

  public void setNameOfCompany(String nameOfCompany) {
    this.nameOfCompany = nameOfCompany;
  }

  public String getAddress() {
    return address;
  }

  public void setAddress(String address) {
    this.address = address;
  }

  public String getRepresentativeName() {
    return representativeName;
  }

  public void setRepresentativeName(String representativeName) {
    this.representativeName = representativeName;
  }

  public String getPhoneNumber() {
    return phoneNumber;
  }

  public void setPhoneNumber(String phoneNumber) {
    this.phoneNumber = phoneNumber;
  }

  @Override
  public String toString() {
    return "Vender{" +
      "nameOfCompany='" + nameOfCompany + '\'' +
      ", address='" + address + '\'' +
      ", representativeName='" + representativeName + '\'' +
      ", phoneNumber='" + phoneNumber + '\'' +
      '}';
  }
}
