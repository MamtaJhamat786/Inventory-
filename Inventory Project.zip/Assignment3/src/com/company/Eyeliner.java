package com.company;

public class Cosmetic extends Product{
  private String productTitle;

  public Cosmetic(String productTitle) {
    this.productTitle = productTitle;
  }

  public Cosmetic(int productNumber, String productName, int productUnitStock,
                  double productUnitPrice, String productTitle) {
    super(productNumber, productName, productUnitStock, productUnitPrice);
    this.productTitle = productTitle;
  }

  public String getProductTitle() {
    return productTitle;
  }

  public void setProductTitle(String productTitle) {
    this.productTitle = productTitle;
  }
  public double restockFee()
  {
    double restockPrice =+ (super.getProductInventory()*0.05);
    return restockPrice;

  }

  @Override
  public String toString() {
    return "ProductChild{" +
      "productTitle='" + productTitle + '\'' +
      '}';
  }
}
