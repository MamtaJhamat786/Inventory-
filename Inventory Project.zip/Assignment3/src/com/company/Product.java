package com.company;

public class Product {
  private int productNumber;
  private String productName;
  private int productUnitStock;
  private double productUnitPrice;
  private double productInventory;
  private Vender productVendor;


  public Product(int productNumber, String productName, int productUnitStock, double productUnitPrice) {
    this.productNumber = productNumber;
    this.productName = productName;
    this.productUnitStock = productUnitStock;
    this.productUnitPrice = productUnitPrice;
  }

  public void setProductVendor(Vender productVendor){
    if (this.productVendor != null){
      System.out.println(this.productName + " is already assigned to vendor " + this.productVendor);
    }else {
      this.productVendor = productVendor;
    }
  }

  public Vender getProductVendor() {
    if (this.productVendor != null){
      return this.productVendor;
    }else {
      System.out.println(this.productName + " does not have a vendor yet, please assign one!");
      return null;
    }
  }

  public Product(){

  }


  public String getProductName() {
    return productName;
  }

  public void setProductName(String productName) {
    this.productName = productName;
  }

  public int getProductNumber() {
    return productNumber;
  }

  public void setProductNumber(int productNumber) {
    this.productNumber = productNumber;
  }

  public int getProductUnitStock() {
    return productUnitStock;
  }

  public void setProductUnitStock(int productUnitStock) {
    this.productUnitStock = productUnitStock;
  }

  public double getProductUnitPrice() {
    return productUnitPrice;
  }

  public void setProductUnitPrice(double productUnitPrice) {
    this.productUnitPrice = productUnitPrice;
  }
  public double calcValue()
  {
    productInventory = productUnitStock*productUnitPrice;
    return productInventory;
  }

  public double getProductInventory() {
    return this.calcValue();
  }

  @Override
  public String toString() {
    return "Product{" +
      "productNumber=" + productNumber +
      ", productName='" + productName + '\'' +
      ", productUnitStock=" + productUnitStock +
      ", productUnitPrice=" + productUnitPrice +
       "value for inventory item left is =" + productInventory +
      "Product Vendor is =" + productVendor.toString() +
      '}';
  }
}
