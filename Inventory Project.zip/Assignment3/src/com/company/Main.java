package com.company;
import java.util.ArrayList;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

      Cosmetic cosmetic = new Cosmetic(1, "Ring", 2, 100, "Cosmetic");
      Cosmetic cosmetic1 = new Cosmetic(2, "eyeliner", 2, 3, "Cosmetic");


        Product product1= new Product(101,"Ring",20,50);
        Product product2= new Product(102,"wrist Watch",10,80);
        Product product3= new Product(103,"eyeliner",30,10);
        Product product4= new Product(104,"Foundation",15,50);
        Product product5= new Product(105,"makeup kit",30,70);
        Product product6= new Product(106,"nailpaint",50,5);



        Vender vendor1 = new Vender("Loreal", "Vilde tee", "mamta", "5638237873");
        Vender vendor2 = new Vender("Lakme", "Mustamae tee", "Nilam", "53952494");
        Vender vendor3 = new Vender("Chanel", "Suur sojame", "Inder", "535687334");
        Vender vendor4 = new Vender("NYX", "lasnamae", "happy", "6755875");
        Vender vendor5 = new Vender("Maybellin", "Old town", "Guri", "3243564");
        Vender vendor6 = new Vender("MAC", "kadriorg", "sangita", "565876578");

       // product1.setProductVendor(vendor1);
        product2.setProductVendor(vendor2);
        product3.setProductVendor(vendor3);
        product4.setProductVendor(vendor4);
        product5.setProductVendor(vendor5);
        product6.setProductVendor(vendor6);

      ArrayList<Product> arrayOfProducts = new ArrayList<>();
      arrayOfProducts.add(product1);
      arrayOfProducts.add(product2);
      arrayOfProducts.add(product3);
      arrayOfProducts.add(product4);
      arrayOfProducts.add(product5);
      arrayOfProducts.add(product6);

        for (int i = 0; i < arrayOfProducts.size(); i++) {
          System.out.println("Product number is :"+arrayOfProducts.get(i).getProductNumber()+
                              " ,Product name is: "+arrayOfProducts.get(i).getProductName()+
                               " ,Number Of unit in stock: "+arrayOfProducts.get(i).getProductUnitStock()+
                              " ,The price of each unit is : "+arrayOfProducts.get(i).getProductUnitPrice()
                               );
          System.out.println("The Value of this inventory item left is : " + arrayOfProducts.get(i).getProductInventory());
          System.out.println("Product Vendor info :" + arrayOfProducts.get(i).getProductVendor());
        }
      System.out.println(cosmetic.getProductName() + " Restocking fee : " + cosmetic.restockFee() );
      System.out.println(cosmetic1.getProductName() + " Restocking fee : " + cosmetic1.restockFee() );


        Scanner sc= new Scanner(System.in);

        boolean answer = false;
        while (!answer){
          System.out.print("Do you wish to add a product( 1= YES ): (  2= NO ) ");
          int response = sc.nextInt();
          if (response==1){
            System.out.print("How many products do you want to add: ");
            int length=sc.nextInt();
            String[] input = new String[length];

            for (int i = 0; i < length; i++) {
              //Innitialize Product
              Product tempProduct = new Product();

              System.out.println("== Entering Product " + (i+1) + " ==");
              System.out.print(" Enter productNumber that you want to add: ");
              tempProduct.setProductNumber(sc.nextInt());

              System.out.print("Enter name of the product ");
              tempProduct.setProductName(sc.next());

              System.out.print(" Enter number of the unit in stock");
              tempProduct.setProductUnitStock(sc.nextInt());

              System.out.print("Enter price of unit");
              tempProduct.setProductUnitPrice(sc.nextDouble());


              System.out.println(" New product Number is:" + tempProduct.getProductNumber() +
                "New product name is: _" + tempProduct.getProductName() +
                "Number of unit in stock are: _" + tempProduct.getProductUnitStock() +
                "New product unit price is: _" + tempProduct.getProductUnitPrice()
              );
              System.out.println("The value of this stock left is : " + (tempProduct.getProductUnitPrice() * tempProduct.getProductUnitStock()));
              input[i]=sc.nextLine();
              arrayOfProducts.add(tempProduct);
              tempProduct.setProductVendor(vendor2);
              System.out.println("The vendor for the product you entered is" +vendor2);
            }
          }
          else
            break;
          answer = true;
        }
      System.out.println("Number of Products : " + arrayOfProducts.size());
    }
}
